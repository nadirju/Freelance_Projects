Forked for upgrade from https://github.com/lukaneco/Raspberry-Pi-3-library-for-kicad
Big thanks to lukaneco for his great job on Raspberry 3 version.

//editing - WIP

These are basic Raspberry Pi 4 schematic symbols and 3D footprints to be used on KiCad.

If you find any errors or problems please send your feedback. Thanks!

//add images when done
